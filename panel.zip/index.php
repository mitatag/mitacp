<?php
session_start();
include 'config.php';
if(!isset($_SESSION['admin'])) header("Location: admin/login.php");

echo "<!DOCTYPE html><html><head>
<title>MITACP</title>
<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css'>
</head><body>";
echo "<nav class='navbar navbar-dark bg-dark'>
<a class='navbar-brand' href='#'>MITACP</a>
<span class='navbar-text'>Admin: $ADMIN_USER</span>
</nav>";
echo "<div class='container mt-4'>
<h3>Dashboard</h3>
<ul class='list-group'>
<li class='list-group-item'>Number of Domains: ".count(glob('/home/*'))."</li>
<li class='list-group-item'>Number of Databases: ";
$mysqli = new mysqli($db_host,$db_user,$db_pass);
$res = $mysqli->query("SHOW DATABASES");
echo $res->num_rows;
echo "</li>
<li class='list-group-item'>Server IP: ".file_get_contents('https://ipinfo.io/ip')."</li>
</ul></div>";
echo "<footer class='text-center mt-5'>MITACP Panel &copy; ".date('Y')."</footer>";
echo "</body></html>";
?>
