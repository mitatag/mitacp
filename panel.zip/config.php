<?php
$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'admin123456';
$db_name = 'mitacp';
$ADMIN_USER = 'admin';
$ADMIN_PASS = password_hash('admin123456', PASSWORD_DEFAULT);
?>
