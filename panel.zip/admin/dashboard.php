<?php
session_start();
include '../config.php';
if(!isset($_SESSION['admin'])) header("Location: login.php");
echo "<h3>Welcome to MITACP Admin Panel</h3>";
echo "<ul>
<li><a href='domains.php'>Manage Domains</a></li>
<li><a href='databases.php'>Manage Databases</a></li>
<li><a href='files.php'>File Manager</a></li>
<li><a href='ssl.php'>SSL Certificates</a></li>
<li><a href='settings.php'>Change Admin Password</a></li>
</ul>";
?>
