<?php
session_start();
include '../config.php';
if(!isset($_SESSION['admin'])) exit;

if(isset($_POST['newpass'])){
    $hash = password_hash($_POST['newpass'], PASSWORD_DEFAULT);
    $cfg = "<?php
\$db_host = '$db_host';
\$db_user = '$db_user';
\$db_pass = '$db_pass';
\$db_name = '$db_name';
\$ADMIN_USER = '$ADMIN_USER';
\$ADMIN_PASS = '$hash';
?>";
    file_put_contents('../config.php',$cfg);
    echo "Password updated successfully!";
}
?>
<form method="POST">
<input type="password" name="newpass" placeholder="New Admin Password"/><br><br>
<input type="submit" value="Update"/>
</form>
