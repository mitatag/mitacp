<?php
session_start();
include '../config.php';
if(isset($_POST['user'], $_POST['pass'])){
    if($_POST['user']==$ADMIN_USER && password_verify($_POST['pass'], $ADMIN_PASS)){
        $_SESSION['admin']=true;
        header("Location: dashboard.php");
        exit;
    } else {
        $error="Invalid credentials";
    }
}
?>
<form method="POST" style="margin:50px">
<input name="user" placeholder="Username"/><br><br>
<input name="pass" type="password" placeholder="Password"/><br><br>
<input type="submit" value="Login"/>
<?php if(isset($error)) echo "<p style='color:red'>$error</p>"; ?>
</form>
