<?php
session_start();
include '../config.php';
if(!isset($_SESSION['admin'])) exit;

if(isset($_POST['domain'])){
    $domain = preg_replace("/[^a-zA-Z0-9.-]/","",$_POST['domain']);
    $folder = "/home/".$domain."/public_html/";
    if(!is_dir($folder)) mkdir($folder,0755,true);

    $db = str_replace(".","_",$domain);
    $link = new mysqli($db_host,$db_user,$db_pass);
    $link->query("CREATE DATABASE IF NOT EXISTS $db");
    echo "Domain & DB Created: $domain / $db";
}
?>
<form method="POST">
<input name="domain" placeholder="example.com"/>
<input type="submit" value="Create"/>
</form>
